from PIL import Image, ImageDraw, ImageFont
import numpy as np, math, subprocess, wave
from pathlib import Path
p=Path('/workspace/scratch/a8ee0ceeb0fd/output/aj_semana_27_02/interno/1102_19h_ADL_Curso'); W,H=720,1280
font='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
reg='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
def f(n,b=True):return ImageFont.truetype(font if b else reg,n)
scenes=[(['COMPRANDO', 'ANTES DO', 'LEILÃO.'], 'Conheça a proposta do Método ADL.'), (['BUSCA E', 'AVALIAÇÃO', 'DE VEÍCULOS.'], 'Temas descritos na apresentação do método.'), (['NEGOCIAÇÃO E', 'DOCUMENTAÇÃO.'], 'Confira os assuntos e as condições do treinamento.'), (['VEJA A', 'APRESENTAÇÃO.'], 'Acesse o nosso link para conhecer.')]
y,x=np.mgrid[0:H,0:W]; bg=np.zeros((H,W,3),dtype=np.uint8); glow=np.exp(-((x-530)**2+(y-470)**2)/240000); bg[:,:,0]=8+glow*8;bg[:,:,1]=15+glow*22;bg[:,:,2]=35+glow*46
cmd=['ffmpeg','-y','-loglevel','error','-f','rawvideo','-vcodec','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r','24','-i','-','-an','-c:v','libx264','-preset','fast','-crf','27','-pix_fmt','yuv420p',str(p/'silent.mp4')]
proc=subprocess.Popen(cmd,stdin=subprocess.PIPE)
for k in range(480):
 t=k/24; s=min(int(t/5),3); u=t%5
 im=Image.fromarray(bg.copy());d=ImageDraw.Draw(im)
 for j in range(7):
  xx=int((j*131+t*15)%900-90);yy=int((j*193-t*20)%1400-60);d.ellipse((xx,yy,xx+5,yy+5),fill='#335377')
 d.rounded_rectangle((52,125,122,195),18,fill='#f2c85e');d.text((64,140),'AJ',font=f(32),fill='#0a1730')
 d.text((140,135),'CENTRAL',font=f(23),fill='white');d.text((140,165),'DE OFERTAS',font=f(17,False),fill='#b0bfd8')
 d.text((55,260),['IDEIAS PARA O SEU DIA','UM PASSO POR VEZ','CONFIRA OS DETALHES','CONHEÇA A PROPOSTA'][s],font=f(19),fill='#f2c85e')
 # Animated abstract video card
 cx=360+int(8*math.sin(t));cy=420
 d.rounded_rectangle((cx-105,cy-92,cx+105,cy+92),24,outline='#35577b',width=2,fill='#122b49')
 d.polygon([(cx-17,cy-30),(cx-17,cy+30),(cx+33,cy)],fill='#f2c85e')
 lines,sub=scenes[s]; yy=(530 if s==3 else 565)+int(24*max(0,1-u*3))
 for line in lines:
  size=45
  while d.textlength(line,font=f(size))>610:size-=1
  d.text((55,yy),line,font=f(size),fill='white');yy+=69
 # wrapped subtitle
 words=sub.split();ls=[];line=''
 for w in words:
  if d.textlength(line+' '+w,font=f(25,False))>605:ls.append(line);line=w
  else:line=(line+' '+w).strip()
 ls.append(line)
 for i,line in enumerate(ls):d.text((55,yy+30+i*38),line,font=f(25,False),fill='#bac9df')
 if s==3:
  d.rounded_rectangle((55,865,665,952),22,fill='#f2c85e');d.text((130,890),'ACESSE O NOSSO LINK',font=f(27),fill='#0a1730')
 d.text((55,1055),'ACESSE O NOSSO LINK • PUBLICIDADE',font=f(17),fill='#d5b773')
 d.text((55,1085),'AJ Central de Ofertas',font=f(18,False),fill='#aebbd0')
 for j in range(4):d.rounded_rectangle((55+j*155,1140,195+j*155,1145),2,fill='#f2c85e' if j==s else '#29415e')
 proc.stdin.write(im.tobytes())
proc.stdin.close();assert proc.wait()==0
sr=44100; a=np.arange(sr*20)/sr; sound=np.zeros(len(a))
for n in range(40):
 start=n*.5; dt=a-start;mask=(dt>=0)&(dt<.45);freq=[220,261.63,329.63,293.66][(n//4)%4];sound[mask]+=.09*np.sin(2*np.pi*freq*dt[mask])*np.exp(-dt[mask]*8)
for n in range(40):
 dt=a-n*.5;mask=(dt>=0)&(dt<.17);sound[mask]+=.15*np.sin(2*np.pi*(65*dt[mask]+12*(1-np.exp(-dt[mask]*20))))*np.exp(-dt[mask]*25)
sound*=np.minimum(1,a)*np.minimum(1,(20-a)/1.5)
with wave.open(str(p/'music.wav'),'wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(sr);w.writeframes((sound*32767).astype('<i2').tobytes())
subprocess.run(['ffmpeg','-y','-loglevel','error','-i',str(p/'silent.mp4'),'-i',str(p/'music.wav'),'-c:v','copy','-c:a','aac','-b:a','128k','-movflags','+faststart','-shortest',str(p/'AJ_Videos_Viciantes.mp4')],check=True)
subprocess.run(['ffmpeg','-y','-loglevel','error','-ss','12','-i',str(p/'AJ_Videos_Viciantes.mp4'),'-frames:v','1',str(p/'preview.jpg')],check=True)
print(p/'AJ_Videos_Viciantes.mp4')